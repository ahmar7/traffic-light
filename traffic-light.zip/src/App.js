import React, { useState } from 'react';
import './App.css'
const App = () => {
  return (
    <div>
      <div id="isiqfor">
        <div class="red on"></div>
        <div class="yellow"></div>
        <div class="green "></div>
      </div>
      <button >Start Timer</button>
    </div>

  );
}

export default App;
